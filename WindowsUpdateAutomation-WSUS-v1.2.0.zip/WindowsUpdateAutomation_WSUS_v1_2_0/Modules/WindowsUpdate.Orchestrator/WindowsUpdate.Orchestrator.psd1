@{
RootModule='WindowsUpdate.Orchestrator.psm1'
ModuleVersion='1.2.0'
GUID='8e4a1c2b-0a6f-4f58-9a8c-11c9d9b8d003'
FunctionsToExport=@('Get-WindowsUpdateChangeReport','Invoke-WindowsUpdateCycle')
}
