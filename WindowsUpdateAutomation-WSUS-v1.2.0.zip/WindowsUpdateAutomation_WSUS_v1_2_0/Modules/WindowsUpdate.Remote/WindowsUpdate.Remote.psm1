Set-StrictMode -Version Latest

function Invoke-WuaRemote {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][scriptblock]$ScriptBlock,
        [hashtable]$ArgumentList = @{},
        [pscredential]$Credential
    )

    $params = @{
        ComputerName = $ComputerName
        ScriptBlock  = $ScriptBlock
        ArgumentList = $ArgumentList
        ErrorAction  = 'Stop'
    }

    if ($Credential) {
        $params.Credential = $Credential
    }

    Invoke-Command @params
}

function Test-RemoteWindowsUpdatePrerequisites {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [pscredential]$Credential
    )

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $wu = Get-Service wuauserv -ErrorAction Stop

        [pscustomobject]@{
            ComputerName       = $env:COMPUTERNAME
            OperatingSystem    = $os.Caption
            OSVersion          = $os.Version
            WindowsUpdateState = $wu.Status
            IsAdministrator    = ([Security.Principal.WindowsPrincipal]
                [Security.Principal.WindowsIdentity]::GetCurrent()
            ).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
        }
    }
}

function Get-RemoteWsusConfiguration {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][string]$WsusServer,
        [ValidateRange(1,65535)][int]$WsusPort = 8530,
        [switch]$UseSsl,
        [pscredential]$Credential
    )

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($WsusServer, $WsusPort, $UseSsl)

        $requested = if ($UseSsl) {
            "https://$WsusServer`:$WsusPort"
        } else {
            "http://$WsusServer`:$WsusPort"
        }

        $policy = Get-ItemProperty `
            -Path 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate' `
            -ErrorAction SilentlyContinue

        $configured = [string]$policy.WUServer
        $statusServer = [string]$policy.WUStatusServer

        $reachable = $false
        try {
            $reachable = Test-NetConnection `
                -ComputerName $WsusServer `
                -Port $WsusPort `
                -InformationLevel Quiet `
                -WarningAction SilentlyContinue
        }
        catch {}

        [pscustomobject]@{
            ComputerName             = $env:COMPUTERNAME
            RequestedWSUS            = $requested
            ConfiguredWUServer       = $configured
            ConfiguredWUStatusServer = $statusServer
            WSUSReachable            = [bool]$reachable
            TargetMatchesPolicy      = [bool](
                $configured -and
                $configured.TrimEnd('/') -ieq $requested.TrimEnd('/')
            )
            Port                      = $WsusPort
            UseSsl                    = [bool]$UseSsl
        }
    } -ArgumentList @{
        WsusServer = $WsusServer
        WsusPort   = $WsusPort
        UseSsl     = [bool]$UseSsl
    }
}

function Get-RemoteWindowsUpdate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][string]$WsusServer,
        [ValidateRange(1,65535)][int]$WsusPort = 8530,
        [switch]$UseSsl,
        [switch]$SkipWsusPolicyValidation,
        [pscredential]$Credential
    )

    $config = Get-RemoteWsusConfiguration `
        -ComputerName $ComputerName `
        -WsusServer $WsusServer `
        -WsusPort $WsusPort `
        -UseSsl:$UseSsl `
        -Credential $Credential

    if (-not $config.WSUSReachable) {
        throw "$ComputerName cannot reach WSUS endpoint $($config.RequestedWSUS)."
    }

    if (-not $SkipWsusPolicyValidation -and -not $config.TargetMatchesPolicy) {
        throw "$ComputerName is not configured for requested WSUS endpoint. Configured='$($config.ConfiguredWUServer)' Requested='$($config.RequestedWSUS)'."
    }

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = 'PowerShell Windows Update Automation'

        $searcher = $session.CreateUpdateSearcher()
        $searcher.ServerSelection = 1 # ssManagedServer
        $searcher.Online = $true
        $searcher.IncludePotentiallySupersededUpdates = $false

        $result = $searcher.Search("IsInstalled=0 and IsHidden=0")

        foreach ($update in $result.Updates) {
            [pscustomobject]@{
                ComputerName    = $env:COMPUTERNAME
                UpdateID        = [string]$update.Identity.UpdateID
                RevisionNumber  = [int]$update.Identity.RevisionNumber
                KBArticleIDs    = (@($update.KBArticleIDs) -join ',')
                Title           = [string]$update.Title
                Description     = [string]$update.Description
                Categories      = (@($update.Categories | ForEach-Object { $_.Name }) -join '; ')
                IsDownloaded    = [bool]$update.IsDownloaded
                IsMandatory     = [bool]$update.IsMandatory
                MaxDownloadSize = [int64]$update.MaxDownloadSize
                UpdateSource    = 'WSUS'
            }
        }
    }
}

function Install-RemoteWindowsUpdate {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][object[]]$Updates,
        [pscredential]$Credential
    )

    $requested = @($Updates | ForEach-Object {
        [pscustomobject]@{
            UpdateID       = [string]$_.UpdateID
            RevisionNumber = [int]$_.RevisionNumber
        }
    })

    if ($requested.Count -eq 0) {
        return @()
    }

    if (-not $PSCmdlet.ShouldProcess($ComputerName, "Install $($requested.Count) Windows Update(s)")) {
        return @()
    }

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($RequestedUpdates)

        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = 'PowerShell Windows Update Automation'

        $searcher = $session.CreateUpdateSearcher()
        $searcher.ServerSelection = 1
        $searcher.Online = $true
        $searchResult = $searcher.Search("IsInstalled=0 and IsHidden=0")

        $collection = New-Object -ComObject Microsoft.Update.UpdateColl

        foreach ($wanted in $RequestedUpdates) {
            foreach ($update in $searchResult.Updates) {
                if (
                    [string]$update.Identity.UpdateID -eq $wanted.UpdateID -and
                    [int]$update.Identity.RevisionNumber -eq $wanted.RevisionNumber
                ) {
                    if (-not $update.EulaAccepted) {
                        try { $update.AcceptEula() } catch {}
                    }

                    [void]$collection.Add($update)
                    break
                }
            }
        }

        if ($collection.Count -eq 0) {
            throw "None of the requested updates are still applicable on $env:COMPUTERNAME."
        }

        $downloader = $session.CreateUpdateDownloader()
        $downloader.Updates = $collection
        $downloadResult = $downloader.Download()

        if ([int]$downloadResult.ResultCode -notin 2,3) {
            throw "Download phase failed with ResultCode $($downloadResult.ResultCode)."
        }

        $installer = $session.CreateUpdateInstaller()
        $installer.Updates = $collection
        $installResult = $installer.Install()
        $installDate = Get-Date

        for ($i = 0; $i -lt $collection.Count; $i++) {
            $u = $collection.Item($i)
            $r = $installResult.GetUpdateResult($i)

            [pscustomobject]@{
                ComputerName   = $env:COMPUTERNAME
                UpdateID       = [string]$u.Identity.UpdateID
                RevisionNumber = [int]$u.Identity.RevisionNumber
                KBArticleIDs   = (@($u.KBArticleIDs) -join ',')
                Title          = [string]$u.Title
                InstallResult  = [int]$r.ResultCode
                HResult        = ('0x{0:X8}' -f ([uint32]$r.HResult))
                RebootRequired = [bool]$r.RebootRequired
                InstallDate    = $installDate
            }
        }
    } -ArgumentList @{
        RequestedUpdates = $requested
    }
}

function Wait-RemoteComputer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [int]$TimeoutSec = 900,
        [int]$PollSec = 10,
        [pscredential]$Credential
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSec)

    do {
        Start-Sleep -Seconds $PollSec

        try {
            $params = @{
                ComputerName = $ComputerName
                ScriptBlock  = { $env:COMPUTERNAME }
                ErrorAction  = 'Stop'
            }

            if ($Credential) {
                $params.Credential = $Credential
            }

            if (Invoke-Command @params) {
                return $true
            }
        }
        catch {}

    } while ((Get-Date) -lt $deadline)

    return $false
}

Export-ModuleMember -Function @(
    'Invoke-WuaRemote',
    'Test-RemoteWindowsUpdatePrerequisites',
    'Get-RemoteWsusConfiguration',
    'Get-RemoteWindowsUpdate',
    'Install-RemoteWindowsUpdate',
    'Wait-RemoteComputer'
)
