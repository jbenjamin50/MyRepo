@{
RootModule='WindowsUpdate.Reporting.psm1'
ModuleVersion='1.2.0'
GUID='8e4a1c2b-0a6f-4f58-9a8c-11c9d9b8d002'
FunctionsToExport=@('Export-AvailableUpdatesCsv','New-WindowsUpdateChangeReport','Get-UpdateStatusComparison','Export-UpdateStatusReport')
}
