#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory)][string[]]$ComputerName,
    [Parameter(Mandatory)][string]$OutputDirectory,
    [Parameter(Mandatory)][string]$WsusServer,
    [ValidateRange(1,65535)][int]$WsusPort = 8530,
    [switch]$UseSsl,
    [switch]$SkipWsusPolicyValidation,
    [string]$ChangeTicket,
    [string]$RequestedBy,
    [string]$MaintenanceWindow,
    [pscredential]$Credential
)

$moduleRoot = Join-Path $PSScriptRoot 'Modules'

Import-Module (Join-Path $moduleRoot 'WindowsUpdate.Remote\WindowsUpdate.Remote.psd1') -Force
Import-Module (Join-Path $moduleRoot 'WindowsUpdate.Reporting\WindowsUpdate.Reporting.psd1') -Force
Import-Module (Join-Path $moduleRoot 'WindowsUpdate.Orchestrator\WindowsUpdate.Orchestrator.psd1') -Force

Get-WindowsUpdateChangeReport `
    -ComputerName $ComputerName `
    -OutputDirectory $OutputDirectory `
    -WsusServer $WsusServer `
    -WsusPort $WsusPort `
    -UseSsl:$UseSsl `
    -SkipWsusPolicyValidation:$SkipWsusPolicyValidation `
    -ChangeTicket $ChangeTicket `
    -RequestedBy $RequestedBy `
    -MaintenanceWindow $MaintenanceWindow `
    -Credential $Credential `
    -Verbose
