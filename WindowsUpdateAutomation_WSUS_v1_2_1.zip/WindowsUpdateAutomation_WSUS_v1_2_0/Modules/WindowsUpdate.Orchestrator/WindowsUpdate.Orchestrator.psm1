Set-StrictMode -Version Latest

function Get-WindowsUpdateChangeReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]]$ComputerName,
        [Parameter(Mandatory)][string]$OutputDirectory,
        [Parameter(Mandatory)][string]$WsusServer,
        [ValidateRange(1,65535)][int]$WsusPort = 8530,
        [switch]$UseSsl,
        [switch]$SkipWsusPolicyValidation,
        [string]$ChangeTicket,
        [string]$RequestedBy,
        [string]$MaintenanceWindow,
        [pscredential]$Credential
    )

    $allUpdates = [System.Collections.Generic.List[object]]::new()

    foreach ($server in $ComputerName) {
        Write-Verbose "Scanning $server for WSUS-targeted updates."

        try {
            $updates = @(Get-RemoteWindowsUpdate `
                -ComputerName $server `
                -WsusServer $WsusServer `
                -WsusPort $WsusPort `
                -UseSsl:$UseSsl `
                -SkipWsusPolicyValidation:$SkipWsusPolicyValidation `
                -Credential $Credential)

            $updates = @($updates | Select-Object *,
                @{n='WSUSServer';e={$WsusServer}},
                @{n='WSUSPort';e={$WsusPort}},
                @{n='WSUSSSL';e={[bool]$UseSsl}},
                @{n='ScanStatus';e={'Succeeded'}},
                @{n='ScanError';e={$null}})
        }
        catch {
            Write-Warning "WSUS scan failed for ${server}: $($_.Exception.Message)"
            $updates = @([pscustomobject]@{
                ComputerName = $server
                WSUSServer   = $WsusServer
                WSUSPort     = $WsusPort
                WSUSSSL      = [bool]$UseSsl
                KBArticleIDs = $null
                Title         = $null
                Categories    = $null
                IsMandatory   = $null
                IsDownloaded  = $null
                MaxDownloadSize = 0
                ScanStatus   = 'Failed'
                ScanError    = $_.Exception.Message
            })
        }

        foreach ($item in $updates) {
            $allUpdates.Add($item)
        }
    }

    New-WindowsUpdateChangeReport `
        -Updates @($allUpdates) `
        -OutputDirectory $OutputDirectory `
        -ChangeTicket $ChangeTicket `
        -RequestedBy $RequestedBy `
        -MaintenanceWindow $MaintenanceWindow
}

function Invoke-WindowsUpdateCycle {
    [CmdletBinding(SupportsShouldProcess, ConfirmImpact='High')]
    param(
        [Parameter(Mandatory)][string[]]$ComputerName,
        [Parameter(Mandatory)][string]$OutputDirectory,
        [Parameter(Mandatory)][string]$WsusServer,
        [ValidateRange(1,65535)][int]$WsusPort = 8530,
        [switch]$UseSsl,
        [switch]$SkipWsusPolicyValidation,
        [switch]$SkipReboot,
        [switch]$GenerateChangeReport,
        [string]$ChangeTicket,
        [string]$RequestedBy,
        [string]$MaintenanceWindow,
        [int]$RebootTimeoutSec = 900,
        [pscredential]$Credential
    )

    New-Item -Path $OutputDirectory -ItemType Directory -Force | Out-Null
    $allStatus = [System.Collections.Generic.List[object]]::new()

    foreach ($server in $ComputerName) {
        Write-Verbose "Processing $server"

        $pre = Test-RemoteWindowsUpdatePrerequisites `
            -ComputerName $server `
            -Credential $Credential

        if (-not $pre.IsAdministrator) {
            throw "${server}: remote session is not running with administrator rights."
        }

        $available = @(Get-RemoteWindowsUpdate `
            -ComputerName $server `
            -WsusServer $WsusServer `
            -WsusPort $WsusPort `
            -UseSsl:$UseSsl `
            -SkipWsusPolicyValidation:$SkipWsusPolicyValidation `
            -Credential $Credential)

        $available = @($available | Select-Object *,
            @{n='WSUSServer';e={$WsusServer}},
            @{n='WSUSPort';e={$WsusPort}},
            @{n='WSUSSSL';e={[bool]$UseSsl}})

        $baseline = Join-Path $OutputDirectory "$server-AvailableUpdates.csv"
        Export-AvailableUpdatesCsv -Updates $available -Path $baseline | Out-Null

        if ($GenerateChangeReport) {
            New-WindowsUpdateChangeReport `
                -Updates $available `
                -OutputDirectory $OutputDirectory `
                -ChangeTicket $ChangeTicket `
                -RequestedBy $RequestedBy `
                -MaintenanceWindow $MaintenanceWindow | Out-Null
        }

        if ($available.Count -eq 0) {
            Write-Host "${server}: no applicable WSUS-approved updates found."
            continue
        }

        if (-not $PSCmdlet.ShouldProcess($server, "Install $($available.Count) Windows Update(s)")) {
            continue
        }

        $installResults = @(Install-RemoteWindowsUpdate `
            -ComputerName $server `
            -Updates $available `
            -Credential $Credential `
            -Confirm:$false)

        $needsReboot = @(
            $installResults | Where-Object { $_.RebootRequired }
        ).Count -gt 0

        if ($needsReboot -and -not $SkipReboot) {
            Restart-Computer `
                -ComputerName $server `
                -Credential $Credential `
                -Force `
                -ErrorAction Stop

            if (-not (Wait-RemoteComputer `
                -ComputerName $server `
                -Credential $Credential `
                -TimeoutSec $RebootTimeoutSec)) {

                Write-Warning "$server did not return within $RebootTimeoutSec seconds."
            }
        }

        $post = @(Get-RemoteWindowsUpdate `
            -ComputerName $server `
            -WsusServer $WsusServer `
            -WsusPort $WsusPort `
            -UseSsl:$UseSsl `
            -SkipWsusPolicyValidation:$SkipWsusPolicyValidation `
            -Credential $Credential)

        $status = @(Get-UpdateStatusComparison `
            -AvailableUpdates $available `
            -InstallResults $installResults `
            -PostRebootUpdates $post)

        foreach ($item in $status) {
            $allStatus.Add($item)
        }
    }

    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $csvPath = Join-Path $OutputDirectory "WindowsUpdate-Status-$timestamp.csv"
    $xlsxPath = Join-Path $OutputDirectory "WindowsUpdate-Status-$timestamp.xlsx"

    Export-UpdateStatusReport `
        -Status @($allStatus) `
        -Path $csvPath | Out-Null

    Export-UpdateStatusReport `
        -Status @($allStatus) `
        -Path $xlsxPath `
        -CreatePivot | Out-Null

    [pscustomobject]@{
        StatusCsv   = $csvPath
        PivotReport = $xlsxPath
        StatusRows  = $allStatus.Count
    }
}

Export-ModuleMember -Function @(
    'Get-WindowsUpdateChangeReport',
    'Invoke-WindowsUpdateCycle'
)
