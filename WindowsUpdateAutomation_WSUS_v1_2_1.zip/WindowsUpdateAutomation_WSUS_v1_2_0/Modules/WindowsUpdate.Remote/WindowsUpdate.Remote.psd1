@{
RootModule='WindowsUpdate.Remote.psm1'
ModuleVersion='1.2.1'
GUID='8e4a1c2b-0a6f-4f58-9a8c-11c9d9b8d001'
FunctionsToExport=@('Invoke-WuaRemote','Test-RemoteWindowsUpdatePrerequisites','Get-RemoteWsusConfiguration','Get-RemoteWindowsUpdate','Install-RemoteWindowsUpdate','Wait-RemoteComputer')
}
