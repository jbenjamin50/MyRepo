Set-StrictMode -Version Latest

function Invoke-WuaRemote {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][scriptblock]$ScriptBlock,
        [object[]]$ArgumentList = @(),
        [pscredential]$Credential
    )

    $params = @{
        ComputerName = $ComputerName
        ScriptBlock  = $ScriptBlock
        ArgumentList = $ArgumentList
        ErrorAction  = 'Stop'
    }

    if ($Credential) {
        $params.Credential = $Credential
    }

    Invoke-Command @params
}

function Test-RemoteWindowsUpdatePrerequisites {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [pscredential]$Credential
    )

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        $os = Get-CimInstance Win32_OperatingSystem -ErrorAction Stop
        $wu = Get-Service wuauserv -ErrorAction Stop

        $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
        $principal = New-Object Security.Principal.WindowsPrincipal $identity

        [pscustomobject]@{
            ComputerName       = $env:COMPUTERNAME
            OperatingSystem    = $os.Caption
            OSVersion          = $os.Version
            WindowsUpdateState = $wu.Status
            IsAdministrator    = $principal.IsInRole(
                [Security.Principal.WindowsBuiltInRole]::Administrator
            )
        }
    }
}

function Get-RemoteWsusConfiguration {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][string]$WsusServer,
        [ValidateRange(1,65535)][int]$WsusPort = 8530,
        [switch]$UseSsl,
        [pscredential]$Credential
    )

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($WsusServer, $WsusPort, $UseSsl)

        function Test-TcpEndpoint {
            param(
                [Parameter(Mandatory)][string]$HostName,
                [Parameter(Mandatory)][int]$Port,
                [int]$TimeoutMilliseconds = 5000
            )

            $client = New-Object System.Net.Sockets.TcpClient
            try {
                $operation = $client.BeginConnect($HostName, $Port, $null, $null)
                if (-not $operation.AsyncWaitHandle.WaitOne($TimeoutMilliseconds, $false)) {
                    return [pscustomobject]@{
                        Reachable = $false
                        Error     = "TCP connection timed out after $TimeoutMilliseconds ms."
                    }
                }

                $client.EndConnect($operation)
                [pscustomobject]@{ Reachable = $true; Error = $null }
            }
            catch {
                [pscustomobject]@{
                    Reachable = $false
                    Error     = $_.Exception.Message
                }
            }
            finally {
                $client.Close()
            }
        }

        $scheme = if ($UseSsl) { 'https' } else { 'http' }
        $requested = '{0}://{1}:{2}' -f $scheme, $WsusServer, $WsusPort
        $policyPath = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
        $auPolicyPath = Join-Path $policyPath 'AU'
        $configurationError = $null

        try {
            $policy = Get-ItemProperty -LiteralPath $policyPath -ErrorAction Stop
            $auPolicy = Get-ItemProperty -LiteralPath $auPolicyPath -ErrorAction Stop
        }
        catch {
            $configurationError = $_.Exception.Message
            $policy = $null
            $auPolicy = $null
        }

        $configured = if ($policy) { [string]$policy.WUServer } else { $null }
        $statusServer = if ($policy) { [string]$policy.WUStatusServer } else { $null }
        $useWUServer = if ($auPolicy -and $null -ne $auPolicy.UseWUServer) {
            [int]$auPolicy.UseWUServer
        } else {
            0
        }

        $configuredUri = $null
        $requestedUri = $null
        try { $requestedUri = [Uri]$requested } catch {
            $configurationError = "Requested WSUS endpoint is invalid: $($_.Exception.Message)"
        }
        if ($configured) {
            try { $configuredUri = [Uri]$configured } catch {
                $configurationError = "Configured WUServer is not a valid URI: $configured"
            }
        }
        elseif (-not $configurationError) {
            $configurationError = 'The WUServer policy value is missing.'
        }

        $sameHost = $false
        if ($configuredUri -and $requestedUri) {
            $sameHost = $configuredUri.DnsSafeHost -ieq $requestedUri.DnsSafeHost
            if (-not $sameHost) {
                try {
                    $configuredAddresses = @(
                        [Net.Dns]::GetHostAddresses($configuredUri.DnsSafeHost) |
                            ForEach-Object { $_.IPAddressToString }
                    )
                    $requestedAddresses = @(
                        [Net.Dns]::GetHostAddresses($requestedUri.DnsSafeHost) |
                            ForEach-Object { $_.IPAddressToString }
                    )
                    $sameHost = @(
                        $configuredAddresses |
                            Where-Object { $requestedAddresses -contains $_ }
                    ).Count -gt 0
                }
                catch {
                    if (-not $configurationError) {
                        $configurationError = "DNS comparison failed: $($_.Exception.Message)"
                    }
                }
            }
        }

        $targetMatchesPolicy = [bool](
            $configuredUri -and
            $requestedUri -and
            $sameHost -and
            $configuredUri.Scheme -ieq $requestedUri.Scheme -and
            $configuredUri.Port -eq $requestedUri.Port
        )

        $tcpHost = if ($configuredUri) { $configuredUri.DnsSafeHost } else { $WsusServer }
        $tcpPort = if ($configuredUri) { $configuredUri.Port } else { $WsusPort }
        $tcpTest = Test-TcpEndpoint -HostName $tcpHost -Port $tcpPort

        [pscustomobject]@{
            ComputerName             = $env:COMPUTERNAME
            RequestedWSUS            = $requested
            ConfiguredWUServer       = $configured
            ConfiguredWUStatusServer = $statusServer
            UseWUServer              = $useWUServer
            WSUSReachable            = [bool]$tcpTest.Reachable
            TcpDiagnostic            = $tcpTest.Error
            ConfigurationError       = $configurationError
            TargetMatchesPolicy      = $targetMatchesPolicy
            Port                      = $WsusPort
            UseSsl                    = [bool]$UseSsl
        }
    } -ArgumentList @($WsusServer, $WsusPort, [bool]$UseSsl)
}

function Get-RemoteWindowsUpdate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][string]$WsusServer,
        [ValidateRange(1,65535)][int]$WsusPort = 8530,
        [switch]$UseSsl,
        [switch]$SkipWsusPolicyValidation,
        [pscredential]$Credential
    )

    $config = Get-RemoteWsusConfiguration `
        -ComputerName $ComputerName `
        -WsusServer $WsusServer `
        -WsusPort $WsusPort `
        -UseSsl:$UseSsl `
        -Credential $Credential

    if ($config.ConfigurationError) {
        throw "$ComputerName has an invalid or incomplete WSUS policy: $($config.ConfigurationError)"
    }

    if ($config.UseWUServer -ne 1) {
        throw "$ComputerName is not configured to use its managed WSUS server (UseWUServer=$($config.UseWUServer))."
    }

    if (-not $SkipWsusPolicyValidation -and -not $config.TargetMatchesPolicy) {
        throw "$ComputerName is not configured for requested WSUS endpoint. Configured='$($config.ConfiguredWUServer)' Requested='$($config.RequestedWSUS)'."
    }

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($WsusDiagnostic)

        try {
            $session = New-Object -ComObject Microsoft.Update.Session
            $session.ClientApplicationID = 'PowerShell Windows Update Automation'

            $searcher = $session.CreateUpdateSearcher()
            $searcher.ServerSelection = 1 # ssManagedServer
            $searcher.Online = $true
            $searcher.IncludePotentiallySupersededUpdates = $false

            $result = $searcher.Search("IsInstalled=0 and IsHidden=0")
        }
        catch {
            $hresult = '0x{0:X8}' -f ([uint32]$_.Exception.HResult)
            $tcpDetail = if ($WsusDiagnostic.WSUSReachable) {
                'TCP connection succeeded.'
            } else {
                "TCP diagnostic failed: $($WsusDiagnostic.TcpDiagnostic)"
            }
            throw "Managed WSUS search failed with HRESULT $hresult. $tcpDetail $($_.Exception.Message)"
        }

        foreach ($update in $result.Updates) {
            [pscustomobject]@{
                ComputerName    = $env:COMPUTERNAME
                UpdateID        = [string]$update.Identity.UpdateID
                RevisionNumber  = [int]$update.Identity.RevisionNumber
                KBArticleIDs    = (@($update.KBArticleIDs) -join ',')
                Title           = [string]$update.Title
                Description     = [string]$update.Description
                Categories      = (@($update.Categories | ForEach-Object { $_.Name }) -join '; ')
                IsDownloaded    = [bool]$update.IsDownloaded
                IsMandatory     = [bool]$update.IsMandatory
                MaxDownloadSize = [int64]$update.MaxDownloadSize
                UpdateSource    = 'WSUS'
                ConfiguredWSUS  = [string]$WsusDiagnostic.ConfiguredWUServer
                WsusTcpReachable = [bool]$WsusDiagnostic.WSUSReachable
                WsusTcpDiagnostic = [string]$WsusDiagnostic.TcpDiagnostic
            }
        }
    } -ArgumentList @($config)
}

function Install-RemoteWindowsUpdate {
    [CmdletBinding(SupportsShouldProcess)]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [Parameter(Mandatory)][object[]]$Updates,
        [pscredential]$Credential
    )

    $requested = @($Updates | ForEach-Object {
        [pscustomobject]@{
            UpdateID       = [string]$_.UpdateID
            RevisionNumber = [int]$_.RevisionNumber
        }
    })

    if ($requested.Count -eq 0) {
        return @()
    }

    if (-not $PSCmdlet.ShouldProcess($ComputerName, "Install $($requested.Count) Windows Update(s)")) {
        return @()
    }

    Invoke-WuaRemote -ComputerName $ComputerName -Credential $Credential -ScriptBlock {
        param($RequestedUpdates)

        $session = New-Object -ComObject Microsoft.Update.Session
        $session.ClientApplicationID = 'PowerShell Windows Update Automation'

        $searcher = $session.CreateUpdateSearcher()
        $searcher.ServerSelection = 1
        $searcher.Online = $true
        $searchResult = $searcher.Search("IsInstalled=0 and IsHidden=0")

        $collection = New-Object -ComObject Microsoft.Update.UpdateColl

        foreach ($wanted in $RequestedUpdates) {
            foreach ($update in $searchResult.Updates) {
                if (
                    [string]$update.Identity.UpdateID -eq $wanted.UpdateID -and
                    [int]$update.Identity.RevisionNumber -eq $wanted.RevisionNumber
                ) {
                    if (-not $update.EulaAccepted) {
                        try { $update.AcceptEula() } catch {}
                    }

                    [void]$collection.Add($update)
                    break
                }
            }
        }

        if ($collection.Count -eq 0) {
            throw "None of the requested updates are still applicable on $env:COMPUTERNAME."
        }

        $downloader = $session.CreateUpdateDownloader()
        $downloader.Updates = $collection
        $downloadResult = $downloader.Download()

        if ([int]$downloadResult.ResultCode -notin 2,3) {
            throw "Download phase failed with ResultCode $($downloadResult.ResultCode)."
        }

        $installer = $session.CreateUpdateInstaller()
        $installer.Updates = $collection
        $installResult = $installer.Install()
        $installDate = Get-Date

        for ($i = 0; $i -lt $collection.Count; $i++) {
            $u = $collection.Item($i)
            $r = $installResult.GetUpdateResult($i)

            [pscustomobject]@{
                ComputerName   = $env:COMPUTERNAME
                UpdateID       = [string]$u.Identity.UpdateID
                RevisionNumber = [int]$u.Identity.RevisionNumber
                KBArticleIDs   = (@($u.KBArticleIDs) -join ',')
                Title          = [string]$u.Title
                InstallResult  = [int]$r.ResultCode
                HResult        = ('0x{0:X8}' -f ([uint32]$r.HResult))
                RebootRequired = [bool](
                    $r.RebootRequired -or $installResult.RebootRequired
                )
                InstallDate    = $installDate
                InstallBatchCompletedAt = $installDate
            }
        }
    } -ArgumentList (, $requested)
}

function Wait-RemoteComputer {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$ComputerName,
        [int]$TimeoutSec = 900,
        [int]$PollSec = 10,
        [pscredential]$Credential
    )

    $deadline = (Get-Date).AddSeconds($TimeoutSec)

    do {
        Start-Sleep -Seconds $PollSec

        try {
            $params = @{
                ComputerName = $ComputerName
                ScriptBlock  = { $env:COMPUTERNAME }
                ErrorAction  = 'Stop'
            }

            if ($Credential) {
                $params.Credential = $Credential
            }

            if (Invoke-Command @params) {
                return $true
            }
        }
        catch {}

    } while ((Get-Date) -lt $deadline)

    return $false
}

Export-ModuleMember -Function @(
    'Invoke-WuaRemote',
    'Test-RemoteWindowsUpdatePrerequisites',
    'Get-RemoteWsusConfiguration',
    'Get-RemoteWindowsUpdate',
    'Install-RemoteWindowsUpdate',
    'Wait-RemoteComputer'
)
