Set-StrictMode -Version Latest

function Export-AvailableUpdatesCsv {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Updates,
        [Parameter(Mandatory)][string]$Path
    )

    $parent = Split-Path -Parent $Path
    if ($parent) {
        New-Item -Path $parent -ItemType Directory -Force | Out-Null
    }

    $Updates |
        Select-Object ComputerName,WSUSServer,WSUSPort,WSUSSSL,UpdateID,
            RevisionNumber,KBArticleIDs,Title,Categories,IsDownloaded,
            IsMandatory,MaxDownloadSize |
        Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8

    Get-Item $Path
}

function New-WindowsUpdateChangeReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Updates,
        [Parameter(Mandatory)][string]$OutputDirectory,
        [string]$ChangeTicket,
        [string]$RequestedBy,
        [string]$MaintenanceWindow
    )

    New-Item -Path $OutputDirectory -ItemType Directory -Force | Out-Null

    $timestamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    $csvPath = Join-Path $OutputDirectory "WindowsUpdate-ChangeReport-$timestamp.csv"
    $xlsxPath = Join-Path $OutputDirectory "WindowsUpdate-ChangeReport-$timestamp.xlsx"

    $report = @(
        $Updates | ForEach-Object {
            [pscustomobject]@{
                ChangeTicket      = $ChangeTicket
                RequestedBy       = $RequestedBy
                MaintenanceWindow = $MaintenanceWindow
                ReportGenerated   = Get-Date
                Server            = $_.ComputerName
                WSUSServer        = $_.WSUSServer
                WSUSPort          = $_.WSUSPort
                WSUSSSL           = $_.WSUSSSL
                KBArticleIDs      = $_.KBArticleIDs
                WindowsUpdate     = $_.Title
                Categories        = $_.Categories
                IsMandatory       = $_.IsMandatory
                IsDownloaded      = $_.IsDownloaded
                DownloadSizeMB    = if ($_.MaxDownloadSize) {
                    [math]::Round($_.MaxDownloadSize / 1MB, 2)
                } else {
                    0
                }
                ScanStatus        = if ($_.PSObject.Properties['ScanStatus']) {
                    $_.ScanStatus
                } else {
                    'Succeeded'
                }
                ScanError         = if ($_.PSObject.Properties['ScanError']) {
                    $_.ScanError
                } else {
                    $null
                }
                PlannedAction     = if (
                    $_.PSObject.Properties['ScanStatus'] -and
                    $_.ScanStatus -eq 'Failed'
                ) { 'Investigate' } else { 'Install' }
            }
        }
    )

    if ($report.Count -eq 0) {
        $report = @([pscustomobject]@{
            ChangeTicket      = $ChangeTicket
            RequestedBy       = $RequestedBy
            MaintenanceWindow = $MaintenanceWindow
            ReportGenerated   = Get-Date
            Server            = $null
            WSUSServer        = $null
            WSUSPort          = $null
            WSUSSSL           = $null
            KBArticleIDs      = $null
            WindowsUpdate     = $null
            Categories        = $null
            IsMandatory       = $null
            IsDownloaded      = $null
            DownloadSizeMB    = 0
            ScanStatus        = 'SucceededNoUpdates'
            ScanError         = $null
            PlannedAction     = 'None'
        })
    }

    $report | Export-Csv -Path $csvPath -NoTypeInformation -Encoding UTF8

    if (Get-Module -ListAvailable -Name ImportExcel) {
        Import-Module ImportExcel -ErrorAction Stop

        $report | Export-Excel `
            -Path $xlsxPath `
            -WorksheetName 'Targeted Updates' `
            -AutoSize `
            -FreezeTopRow `
            -AutoFilter `
            -BoldTopRow
    }

    [pscustomobject]@{
        ChangeReportCsv  = $csvPath
        ChangeReportXlsx = if (Test-Path $xlsxPath) { $xlsxPath } else { $null }
        UpdateCount      = @($Updates | Where-Object { $_.ScanStatus -ne 'Failed' }).Count
        FailedScanCount  = @($Updates | Where-Object { $_.ScanStatus -eq 'Failed' }).Count
    }
}

function Get-UpdateStatusComparison {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$AvailableUpdates,
        [object[]]$InstallResults = @(),
        [object[]]$PostRebootUpdates = @()
    )

    $installById = @{}
    foreach ($r in @($InstallResults)) {
        $installById["$($r.UpdateID):$($r.RevisionNumber)"] = $r
    }

    $postById = @{}
    foreach ($u in @($PostRebootUpdates)) {
        $postById["$($u.UpdateID):$($u.RevisionNumber)"] = $u
    }

    foreach ($u in @($AvailableUpdates)) {
        $key = "$($u.UpdateID):$($u.RevisionNumber)"
        $result = $installById[$key]
        $stillPending = $postById.ContainsKey($key)

        $status = 'NotAttempted'

        if ($result) {
            switch ([int]$result.InstallResult) {
                2 { $status = if ($stillPending) { 'Succeeded-But-Still-Pending' } else { 'Succeeded' } }
                3 { $status = 'SucceededWithErrors' }
                4 { $status = 'Failed' }
                5 { $status = 'Aborted' }
                default { $status = "InstallResultCode-$($result.InstallResult)" }
            }
        }
        elseif ($stillPending) {
            $status = 'Pending'
        }

        [pscustomobject]@{
            Server          = [string]$u.ComputerName
            WSUSServer      = [string]$u.WSUSServer
            WSUSPort        = $u.WSUSPort
            WSUSSSL         = $u.WSUSSSL
            UpdateID        = [string]$u.UpdateID
            RevisionNumber  = [int]$u.RevisionNumber
            KBArticleIDs    = [string]$u.KBArticleIDs
            WindowsUpdate   = [string]$u.Title
            InstallStatus   = $status
            InstallDate     = if ($result) { $result.InstallDate } else { $null }
            HResult         = if ($result) { $result.HResult } else { $null }
            RebootRequired  = if ($result) { $result.RebootRequired } else { $null }
            VerifiedPending = $stillPending
        }
    }
}

function Export-UpdateStatusReport {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Status,
        [Parameter(Mandatory)][string]$Path,
        [switch]$CreatePivot
    )

    $parent = Split-Path -Parent $Path
    if ($parent) {
        New-Item -Path $parent -ItemType Directory -Force | Out-Null
    }

    if ([IO.Path]::GetExtension($Path) -eq '.csv' -and -not $CreatePivot) {
        $Status | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
        return Get-Item $Path
    }

    if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
        throw "ImportExcel is required for XLSX output. Install-Module ImportExcel -Scope CurrentUser"
    }

    Import-Module ImportExcel -ErrorAction Stop

    if (Test-Path $Path) {
        Remove-Item $Path -Force
    }

    $Status | Export-Excel `
        -Path $Path `
        -WorksheetName 'Detail' `
        -AutoSize `
        -FreezeTopRow `
        -AutoFilter

    $pkg = Open-ExcelPackage -Path $Path

    try {
        $ws = $pkg.Workbook.Worksheets['Detail']

        Add-PivotTable `
            -ExcelPackage $pkg `
            -PivotTableName 'WindowsUpdateStatusPivot' `
            -SourceWorkSheet $ws `
            -SourceRange $ws.Dimension.Address `
            -PivotRows @('Server','WindowsUpdate') `
            -PivotColumns @('InstallStatus') `
            -PivotData @{'UpdateID'='Count'} `
            -WorksheetName 'Update Status'
    }
    finally {
        Close-ExcelPackage $pkg
    }

    Get-Item $Path
}

Export-ModuleMember -Function @(
    'Export-AvailableUpdatesCsv',
    'New-WindowsUpdateChangeReport',
    'Get-UpdateStatusComparison',
    'Export-UpdateStatusReport'
)
