# Windows Update Automation - WSUS Edition v1.2.1

## Fixed in v1.2.1
- Corrected positional argument binding for remote WSUS checks and installation.
- Replaced `Test-NetConnection` with an OS-compatible TCP diagnostic.
- Added `UseWUServer`, URI, DNS alias, and configured-policy validation.
- Made the managed-server WUA search authoritative and preserved HRESULT details.
- Added per-server scan failures to the change-management report.
- Added valid zero-update reporting and corrected module parser errors.

## New in v1.2.0
A change-management reporting workflow has been added.

It can scan one or more servers for WSUS-approved/applicable updates and create a ticket-ready report without installing anything.

### Standalone change report
```powershell
$cred = Get-Credential

.\Get-WindowsUpdateChangeReport.ps1 `
  -ComputerName SERVER01,SERVER02 `
  -WsusServer WSUS01.contoso.com `
  -WsusPort 8530 `
  -OutputDirectory C:\WindowsUpdateReports `
  -ChangeTicket CHG0123456 `
  -RequestedBy "Infrastructure Team" `
  -MaintenanceWindow "2026-09-05 22:00-02:00" `
  -Credential $cred
```

The report contains:
- Change ticket
- Requested by
- Maintenance window
- Report generation timestamp
- Server
- WSUS server / port / SSL
- KB
- Windows Update title
- Categories
- Mandatory flag
- Downloaded flag
- Download size in MB
- Planned action = Install

It writes a CSV, and if ImportExcel is installed, an XLSX workbook.

## Optional pre-install report during normal execution
Use:
```powershell
.\Invoke-WindowsUpdateCycle.ps1 `
  -ComputerName SERVER01,SERVER02 `
  -WsusServer WSUS01.contoso.com `
  -OutputDirectory C:\WindowsUpdateReports `
  -GenerateChangeReport `
  -ChangeTicket CHG0123456 `
  -RequestedBy "Infrastructure Team" `
  -MaintenanceWindow "2026-09-05 22:00-02:00" `
  -Credential $cred
```

This produces the change report before installation begins.

## Existing capabilities
- Explicit WSUS server / port / SSL arguments.
- Validation against target WUServer policy.
- WSUS TCP connectivity test.
- Baseline CSV before installation.
- Installation and reboot.
- Post-reboot verification scan.
- Final CSV and XLSX status report.
- InstallDate in the final detailed report.
- PivotTable summary.
