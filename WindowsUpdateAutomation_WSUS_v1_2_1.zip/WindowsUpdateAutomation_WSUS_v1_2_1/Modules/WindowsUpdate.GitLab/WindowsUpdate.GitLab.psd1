@{
RootModule='WindowsUpdate.GitLab.psm1'
ModuleVersion='1.3.0'
GUID='edca5674-44dc-49f5-a837-a334643cff97'
PowerShellVersion='5.1'
Description='GitLab inventory, domain credential, verification, and reporting helpers for Windows update automation.'
FunctionsToExport=@('ConvertTo-WindowsUpdateBoolean','ConvertTo-DomainVariableSuffix','Get-WindowsUpdateCredentialVariableName','Import-WindowsUpdateTargetInventory','Select-WindowsUpdateTarget','New-WindowsUpdateCredential','Write-WindowsUpdateExecutionSummary','Test-WindowsUpdateTargetDomain')
CmdletsToExport=@()
VariablesToExport=@()
AliasesToExport=@()
}
