Set-StrictMode -Version Latest

function ConvertTo-WindowsUpdateBoolean {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string]$Value,
        [Parameter(Mandatory)][string]$Name
    )

    switch ($Value.Trim().ToLowerInvariant()) {
        'true'  { return $true }
        'false' { return $false }
        default { throw "$Name must be either 'true' or 'false'. Received '$Value'." }
    }
}

function ConvertTo-DomainVariableSuffix {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Domain)

    return ($Domain.Trim().ToUpperInvariant() -replace '[^A-Z0-9]', '_')
}

function Get-WindowsUpdateCredentialVariableName {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Domain)

    $suffix = ConvertTo-DomainVariableSuffix -Domain $Domain
    [pscustomobject]@{
        Domain           = $Domain.Trim().ToLowerInvariant()
        Suffix           = $suffix
        UsernameVariable = "WINDOWS_UPDATE_${suffix}_USERNAME"
        PasswordVariable = "WINDOWS_UPDATE_${suffix}_PASSWORD"
    }
}

function Import-WindowsUpdateTargetInventory {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Path)

    if (-not (Test-Path -LiteralPath $Path -PathType Leaf)) {
        throw "Target inventory was not found: $Path"
    }

    $rows = @(Import-Csv -LiteralPath $Path)
    if ($rows.Count -eq 0) {
        throw "Target inventory contains no server rows: $Path"
    }

    $requiredColumns = @('ComputerName','Domain','Environment','Wave','Enabled')
    $actualColumns = @($rows[0].PSObject.Properties.Name)
    $missingColumns = @($requiredColumns | Where-Object { $_ -notin $actualColumns })
    if ($missingColumns.Count -gt 0) {
        throw "Target inventory is missing required column(s): $($missingColumns -join ', ')."
    }

    $inventory = [System.Collections.Generic.List[object]]::new()
    $rowNumber = 1

    foreach ($row in $rows) {
        $rowNumber++
        $computerName = ([string]$row.ComputerName).Trim()
        $domain = ([string]$row.Domain).Trim().ToLowerInvariant()
        $environment = ([string]$row.Environment).Trim()
        $wave = ([string]$row.Wave).Trim()
        $enabledText = ([string]$row.Enabled).Trim()

        if ([string]::IsNullOrWhiteSpace($computerName)) {
            throw "Target inventory row $rowNumber has an empty ComputerName."
        }
        if ($computerName -notmatch '^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$') {
            throw "Target inventory row $rowNumber has an invalid DNS or NetBIOS name: '$computerName'."
        }
        if ([string]::IsNullOrWhiteSpace($domain)) {
            throw "Target inventory row $rowNumber has an empty Domain."
        }
        if ($domain -notmatch '^[A-Za-z0-9](?:[A-Za-z0-9.-]*[A-Za-z0-9])?$') {
            throw "Target inventory row $rowNumber has an invalid Domain: '$domain'."
        }
        if ([string]::IsNullOrWhiteSpace($environment)) {
            throw "Target inventory row $rowNumber has an empty Environment."
        }
        if ([string]::IsNullOrWhiteSpace($wave)) {
            throw "Target inventory row $rowNumber has an empty Wave."
        }

        $enabled = ConvertTo-WindowsUpdateBoolean -Value $enabledText -Name "Enabled on row $rowNumber"
        $description = if ($actualColumns -contains 'Description') {
            ([string]$row.Description).Trim()
        } else {
            $null
        }

        $inventory.Add([pscustomobject]@{
            ComputerName             = $computerName
            Domain                   = $domain
            CredentialVariableSuffix = ConvertTo-DomainVariableSuffix -Domain $domain
            Environment              = $environment
            Wave                     = $wave
            Enabled                  = $enabled
            Description              = $description
        })
    }

    $duplicates = @(
        $inventory |
            Group-Object { $_.ComputerName.ToLowerInvariant() } |
            Where-Object Count -gt 1
    )
    if ($duplicates.Count -gt 0) {
        $duplicateNames = @($duplicates | ForEach-Object { $_.Group[0].ComputerName })
        throw "Target inventory contains duplicate server name(s): $($duplicateNames -join ', ')."
    }

    $suffixConflicts = @(
        $inventory |
            Group-Object CredentialVariableSuffix |
            Where-Object {
                @($_.Group.Domain | Sort-Object -Unique).Count -gt 1
            }
    )
    if ($suffixConflicts.Count -gt 0) {
        $conflictingSuffixes = @($suffixConflicts | ForEach-Object Name)
        throw "Multiple domains resolve to the same credential-variable suffix: $($conflictingSuffixes -join ', ')."
    }

    return @($inventory)
}

function Select-WindowsUpdateTarget {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object[]]$Inventory,
        [Parameter(Mandatory)][string]$TargetEnvironment,
        [Parameter(Mandatory)][string]$TargetWave
    )

    return @(
        $Inventory | Where-Object {
            $_.Enabled -and
            ($TargetEnvironment -eq 'All' -or $_.Environment -ieq $TargetEnvironment) -and
            ($TargetWave -eq 'All' -or $_.Wave -ieq $TargetWave)
        }
    )
}

function New-WindowsUpdateCredential {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string]$Domain)

    $variableNames = Get-WindowsUpdateCredentialVariableName -Domain $Domain
    $userName = [Environment]::GetEnvironmentVariable($variableNames.UsernameVariable, 'Process')
    $password = [Environment]::GetEnvironmentVariable($variableNames.PasswordVariable, 'Process')

    if ([string]::IsNullOrWhiteSpace($userName)) {
        throw "The protected CI/CD variable $($variableNames.UsernameVariable) is not available for domain '$Domain'."
    }
    if ([string]::IsNullOrWhiteSpace($password)) {
        throw "The protected CI/CD variable $($variableNames.PasswordVariable) is not available for domain '$Domain'."
    }

    $securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force
    $credential = [pscredential]::new($userName, $securePassword)
    $password = $null
    [Environment]::SetEnvironmentVariable($variableNames.PasswordVariable, $null, 'Process')
    return $credential
}

function Write-WindowsUpdateExecutionSummary {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][AllowEmptyCollection()][object[]]$Summary,
        [Parameter(Mandatory)][string]$Directory
    )

    $csvPath = Join-Path $Directory 'execution-summary.csv'
    $jsonPath = Join-Path $Directory 'execution-summary.json'

    @($Summary) | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding UTF8
    ConvertTo-Json -InputObject @($Summary) -Depth 5 |
        Set-Content -LiteralPath $jsonPath -Encoding UTF8
}

function Test-WindowsUpdateTargetDomain {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][object[]]$Targets,
        [Parameter(Mandatory)][hashtable]$CredentialsByDomain,
        [Parameter(Mandatory)][string]$Directory
    )

    if (-not (Get-Command -Name Test-RemoteWindowsUpdatePrerequisites -ErrorAction SilentlyContinue)) {
        $remoteManifest = Join-Path $PSScriptRoot '..\WindowsUpdate.Remote\WindowsUpdate.Remote.psd1'
        Import-Module $remoteManifest -ErrorAction Stop
    }

    $verification = [System.Collections.Generic.List[object]]::new()

    foreach ($target in $Targets) {
        try {
            $credential = $CredentialsByDomain[$target.Domain]
            if (-not $credential) {
                throw "No credential was loaded for domain '$($target.Domain)'."
            }

            $result = Test-RemoteWindowsUpdatePrerequisites `
                -ComputerName $target.ComputerName `
                -Credential $credential

            if (-not $result.PartOfDomain) {
                throw "$($target.ComputerName) is not joined to an Active Directory domain."
            }
            if ($result.Domain -ine $target.Domain) {
                throw "$($target.ComputerName) belongs to '$($result.Domain)', not the CSV domain '$($target.Domain)'."
            }
            if (-not $result.IsAdministrator) {
                throw "The selected credential is not an administrator on $($target.ComputerName)."
            }

            $verification.Add([pscustomobject]@{
                ComputerName             = $target.ComputerName
                Domain                   = $target.Domain
                CredentialVariableSuffix = $target.CredentialVariableSuffix
                ActualDomain             = $result.Domain
                PartOfDomain             = $result.PartOfDomain
                IsAdministrator          = $result.IsAdministrator
                Verification             = 'Succeeded'
                Error                    = $null
            })
        }
        catch {
            $verification.Add([pscustomobject]@{
                ComputerName             = $target.ComputerName
                Domain                   = $target.Domain
                CredentialVariableSuffix = $target.CredentialVariableSuffix
                ActualDomain             = $null
                PartOfDomain             = $null
                IsAdministrator          = $null
                Verification             = 'Failed'
                Error                    = $_.Exception.Message
            })
        }
    }

    $verificationPath = Join-Path $Directory 'domain-verification.csv'
    $verification | Export-Csv -LiteralPath $verificationPath -NoTypeInformation -Encoding UTF8

    $failed = @($verification | Where-Object Verification -eq 'Failed')
    if ($failed.Count -gt 0) {
        throw "$($failed.Count) target domain verification(s) failed. Review domain-verification.csv."
    }

    return @($verification)
}

Export-ModuleMember -Function @(
    'ConvertTo-WindowsUpdateBoolean',
    'ConvertTo-DomainVariableSuffix',
    'Get-WindowsUpdateCredentialVariableName',
    'Import-WindowsUpdateTargetInventory',
    'Select-WindowsUpdateTarget',
    'New-WindowsUpdateCredential',
    'Write-WindowsUpdateExecutionSummary',
    'Test-WindowsUpdateTargetDomain'
)
