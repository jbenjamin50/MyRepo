@{
RootModule='WindowsUpdate.Orchestrator.psm1'
ModuleVersion='1.3.0'
GUID='8e4a1c2b-0a6f-4f58-9a8c-11c9d9b8d003'
PowerShellVersion='5.1'
Description='WSUS update discovery and installation orchestration for one or more Windows servers.'
FunctionsToExport=@('Get-WindowsUpdateChangeReport','Invoke-WindowsUpdateCycle')
CmdletsToExport=@()
VariablesToExport=@()
AliasesToExport=@()
}
