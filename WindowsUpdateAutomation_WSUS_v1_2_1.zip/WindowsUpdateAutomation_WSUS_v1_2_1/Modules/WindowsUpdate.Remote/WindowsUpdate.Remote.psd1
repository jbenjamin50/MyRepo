@{
RootModule='WindowsUpdate.Remote.psm1'
ModuleVersion='1.3.0'
GUID='8e4a1c2b-0a6f-4f58-9a8c-11c9d9b8d001'
PowerShellVersion='5.1'
Description='PowerShell remoting, WSUS policy validation, update discovery, installation, and reboot helpers.'
FunctionsToExport=@('Invoke-WuaRemote','Test-RemoteWindowsUpdatePrerequisites','Get-RemoteWsusConfiguration','Get-RemoteWindowsUpdate','Install-RemoteWindowsUpdate','Wait-RemoteComputer')
CmdletsToExport=@()
VariablesToExport=@()
AliasesToExport=@()
}
