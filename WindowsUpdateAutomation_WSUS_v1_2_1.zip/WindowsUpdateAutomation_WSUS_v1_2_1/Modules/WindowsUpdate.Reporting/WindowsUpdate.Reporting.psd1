@{
RootModule='WindowsUpdate.Reporting.psm1'
ModuleVersion='1.3.0'
GUID='8e4a1c2b-0a6f-4f58-9a8c-11c9d9b8d002'
PowerShellVersion='5.1'
Description='CSV and Excel reporting helpers for Windows update discovery and installation results.'
FunctionsToExport=@('Export-AvailableUpdatesCsv','New-WindowsUpdateChangeReport','Get-UpdateStatusComparison','Export-UpdateStatusReport')
CmdletsToExport=@()
VariablesToExport=@()
AliasesToExport=@()
}
