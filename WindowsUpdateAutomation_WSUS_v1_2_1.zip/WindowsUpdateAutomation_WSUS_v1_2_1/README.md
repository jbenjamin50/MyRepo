# Windows Update Automation - WSUS Edition

Current module version: **1.3.0**

## New in v1.3.0

- Added a GitLab pipeline with separate inventory validation, update discovery, and protected manual deployment jobs.
- Added `Modules/WindowsUpdate.GitLab` so target parsing, domain-to-variable mapping, credential creation, target selection, and domain verification are reusable and testable outside the pipeline adapter.
- Added a required `Domain` column to `config/targets/servers.csv`. Each value selects a domain-specific masked-and-hidden GitLab credential pair.
- Added authenticated verification of `Win32_ComputerSystem.Domain`, domain membership, and administrator rights before a scan or deployment can begin.
- Added project-level PowerShell parsing, manifest validation, inventory validation, and domain-variable mapping checks.
- Added safer zero-update CSV/report handling and multi-domain scan/deployment summaries.

## GitLab runner integration

This package now includes a GitLab-ready integration layer:

- `.gitlab-ci.yml` provides validated `validate`, `scan`, and protected manual `deploy` workflows.
- `config/targets/servers.csv` is the version-controlled target inventory.
- `scripts/Test-Project.ps1` validates PowerShell syntax, module manifests, the sample inventory, filters, and domain-variable mapping.
- `scripts/Invoke-GitLabWindowsUpdate.ps1` uses the GitLab integration module to filter targets, consume protected hidden credentials, and record per-server deployment results.
- Multi-domain inventories use a `Domain` column to select domain-specific hidden variables and verify each target's actual Active Directory domain before scanning or installation.
- `docs/GitLab-Deployment-Guide.md` contains the complete project, runner, variable, scheduling, security, and operations setup.

The example server rows are disabled by default. Replace them with approved targets and enable them through a reviewed merge request.

For example, `contoso.com` maps to `WINDOWS_UPDATE_CONTOSO_COM_USERNAME` and `WINDOWS_UPDATE_CONTOSO_COM_PASSWORD`. Credentials never belong in the CSV.

The standalone `Get-WindowsUpdateChangeReport.ps1` and `Invoke-WindowsUpdateCycle.ps1` entry points intentionally keep their existing single-credential interface. For a mixed-domain run, use the GitLab adapter, which groups discovery by domain and invokes deployments one server at a time with the matching credential.

## Fixed in v1.2.1
- Corrected positional argument binding for remote WSUS checks and installation.
- Replaced `Test-NetConnection` with an OS-compatible TCP diagnostic.
- Added `UseWUServer`, URI, DNS alias, and configured-policy validation.
- Made the managed-server WUA search authoritative and preserved HRESULT details.
- Added per-server scan failures to the change-management report.
- Added valid zero-update reporting and corrected module parser errors.

## New in v1.2.0
A change-management reporting workflow has been added.

It can scan one or more servers for WSUS-approved/applicable updates and create a ticket-ready report without installing anything.

### Standalone change report
```powershell
$cred = Get-Credential

.\Get-WindowsUpdateChangeReport.ps1 `
  -ComputerName SERVER01,SERVER02 `
  -WsusServer WSUS01.contoso.com `
  -WsusPort 8530 `
  -OutputDirectory C:\WindowsUpdateReports `
  -ChangeTicket CHG0123456 `
  -RequestedBy "Infrastructure Team" `
  -MaintenanceWindow "2026-09-05 22:00-02:00" `
  -Credential $cred
```

The report contains:
- Change ticket
- Requested by
- Maintenance window
- Report generation timestamp
- Server
- WSUS server / port / SSL
- KB
- Windows Update title
- Categories
- Mandatory flag
- Downloaded flag
- Download size in MB
- Planned action = Install

It writes a CSV, and if ImportExcel is installed, an XLSX workbook.

## Optional pre-install report during normal execution
Use:
```powershell
.\Invoke-WindowsUpdateCycle.ps1 `
  -ComputerName SERVER01,SERVER02 `
  -WsusServer WSUS01.contoso.com `
  -OutputDirectory C:\WindowsUpdateReports `
  -GenerateChangeReport `
  -ChangeTicket CHG0123456 `
  -RequestedBy "Infrastructure Team" `
  -MaintenanceWindow "2026-09-05 22:00-02:00" `
  -Credential $cred
```

This produces the change report before installation begins.

## Existing capabilities
- Explicit WSUS server / port / SSL arguments.
- Validation against target WUServer policy.
- WSUS TCP connectivity test.
- Baseline CSV before installation.
- Installation and reboot.
- Post-reboot verification scan.
- Final CSV and XLSX status report.
- InstallDate in the final detailed report.
- PivotTable summary.
