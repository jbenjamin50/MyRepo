# GitLab deployment guide for WindowsUpdateAutomation_WSUS

## Recommended design

Use one private GitLab project with one dedicated, project-scoped Windows runner on a management server. The runner reaches the target servers over PowerShell remoting; it does not need to be installed on every target. The inventory can contain servers from many Active Directory domains; the `Domain` column determines which domain-specific hidden-variable pair is used for each server. Keep discovery and deployment as different jobs in the same project:

1. `validate_targets` checks PowerShell syntax and module manifests, then validates the committed inventory.
2. `scan_updates` retrieves WSUS-approved, applicable updates and publishes a change report.
3. `deploy_updates` is a blocking manual job, installs the updates, handles reboots, and publishes final reports.

This repository uses GitLab pipeline inputs for non-secret choices and protected, masked-and-hidden CI/CD variables only for credentials. Pipeline inputs have validation and cannot be mutated after pipeline creation, so GitLab recommends them instead of ad hoc pipeline variables.

Use GitLab 18.1 or later so pipeline inputs are generally available. GitLab 17.11 through 18.0 can use the pipeline only when the pipeline-inputs feature is enabled on the instance. The `artifacts:access: maintainer` option can replace `developer` on GitLab 18.4 or later if only Maintainers should download reports.

## Repository layout

Use the contents of this module directory as the GitLab project root:

```text
.
|-- .gitlab-ci.yml
|-- config/
|   `-- targets/
|       `-- servers.csv
|-- docs/
|   `-- GitLab-Deployment-Guide.md
|-- scripts/
|   |-- Test-Project.ps1
|   `-- Invoke-GitLabWindowsUpdate.ps1
|-- Modules/
|   |-- WindowsUpdate.GitLab/
|   |-- WindowsUpdate.Orchestrator/
|   |-- WindowsUpdate.Remote/
|   `-- WindowsUpdate.Reporting/
|-- Get-WindowsUpdateChangeReport.ps1
`-- Invoke-WindowsUpdateCycle.ps1
```

The authoritative server inventory is:

```text
config/targets/servers.csv
```

Do not place passwords, tokens, or other secrets in this CSV.

## 1. Create the GitLab project

1. In GitLab, select **New project** and then **Create blank project**.
2. Name it `windows-update-automation-wsus`.
3. Select the appropriate infrastructure or operations group as the namespace.
4. Set **Visibility Level** to **Private**.
5. Leave **Initialize repository with a README** cleared because this directory already contains the project files.
6. Create the project.
7. From this module directory, initialize and push the repository. Substitute the URL shown by GitLab:

   ```powershell
   git init
   git branch -M main
   git remote add origin https://gitlab.example.com/infrastructure/windows-update-automation-wsus.git
   git add .
   git commit -m "Add WSUS Windows update automation pipeline"
   git push -u origin main
   ```

8. In **Settings > Repository > Branch rules**, protect `main`:
   - Allowed to merge: Maintainers, or the smallest approved operator group.
   - Allowed to push and merge: No one.
   - Force push: Off.
   - Require merge requests and at least one approval where the GitLab tier supports it.
9. Add a `CODEOWNERS` rule for `.gitlab-ci.yml`, `config/targets/**`, `scripts/**`, and `Modules/**` if Code Owner approvals are available.
10. In **Settings > General > Visibility, project features, permissions**, keep the project private and restrict pipeline/job visibility to project members.

Changes to the inventory, pipeline, or PowerShell code can expose deployment credentials at job runtime. Treat them as production changes and require review before merge.

The included workflow intentionally runs only from the protected default branch, so the privileged Windows runner never executes unmerged feature-branch code. If merge-request validation is required, add a separate unprivileged runner with no production network route and no protected variables; do not enable merge-request pipelines on the WSUS deployment runner.

## 2. Prepare the Windows runner host

Use a dedicated, domain-joined Windows Server management VM that is not a WSUS server and not one of the update targets. A Shell executor is practical here because the module uses Windows PowerShell remoting and Windows Update COM APIs, but GitLab documents that the Shell executor is in maintenance mode and has limited isolation. Do not share this runner with unrelated projects.

For multiple domains, first determine whether the runner can authenticate to every target domain using Kerberos and whether DNS, KDC, firewall, and trust requirements are satisfied. The current module uses the default `Invoke-Command -ComputerName` WinRM transport. If a target domain is untrusted or isolated, prefer a dedicated runner inside that domain. The alternative is to add explicit WinRM HTTPS parameters and certificate validation to the remote module. Do not compensate by trying every domain credential or adding a wildcard to TrustedHosts.

The host needs:

- Windows PowerShell 5.1.
- Git for Windows.
- GitLab Runner.
- The `ImportExcel` PowerShell module for final XLSX/pivot reports.
- DNS resolution for all target FQDNs.
- Outbound HTTPS to the GitLab instance.
- WinRM connectivity from the runner to targets, preferably HTTPS on TCP 5986. If the organization uses HTTP/Kerberos, TCP 5985 must be allowed instead.
- Targets must be able to reach the configured WSUS service, normally TCP 8530 for HTTP or 8531 for HTTPS.

Use FQDNs in the CSV so Kerberos can be used. Do not solve name-resolution problems by broadly populating WinRM TrustedHosts.

Install `ImportExcel` from an approved internal repository or, if policy permits, PowerShell Gallery:

```powershell
Install-Module ImportExcel -Scope AllUsers -Repository PSGallery
```

## 3. Create and register the project runner

1. In the GitLab project, go to **Settings > CI/CD > Runners**.
2. Select **New project runner**.
3. Select Windows and add the tag `windows-wsus`.
4. Clear **Run untagged jobs**.
5. Mark the runner **Protected**.
6. Create the runner and copy the short-lived registration command containing its `glrt-` authentication token.
7. On the runner host, open an elevated Windows PowerShell session and install the runner binary under `C:\GitLab-Runner` using GitLab's Windows installation instructions.
8. Run the GitLab-provided registration command, selecting the `shell` executor. The equivalent noninteractive shape is:

   ```powershell
   .\gitlab-runner.exe register `
     --non-interactive `
     --url "https://gitlab.example.com/" `
     --token "glrt-REDACTED" `
     --executor "shell" `
     --shell "powershell" `
     --description "Dedicated WSUS deployment runner"
   ```

9. Install and start GitLab Runner as a Windows service. Use a dedicated runner service identity that is separate from the Windows update deployment identity:

   ```powershell
   .\gitlab-runner.exe install --user ".\gitlab-runner-svc" --password "ENTER-SERVICE-PASSWORD"
   .\gitlab-runner.exe start
   .\gitlab-runner.exe status
   ```

10. Confirm that `C:\GitLab-Runner\config.toml` contains `executor = "shell"` and `shell = "powershell"`.
11. Because the host is dedicated, set its global runner concurrency to one. The pipeline also uses `resource_group` so two deployments for the same environment cannot overlap.

The runner service identity only needs local access to its build directory and outbound access to GitLab. The separate deployment credential supplied through GitLab is used for WinRM and must have the approved administrator rights on target servers. Apply the organization's service-account controls, such as denying interactive logon, limiting the account to the target server groups, and rotating the password.

## 4. Add hidden credentials and configuration

Go to **Settings > CI/CD > Variables** and add a domain-specific username/password pair for each Active Directory DNS domain. Never enter credentials as manual pipeline variables; GitLab warns that values supplied to manual jobs can be viewed when jobs are retried.

| Key | Value | Type | Visibility | Protected | Expand variable reference | Environment scope |
|---|---|---|---|---|---|---|
| `WINDOWS_UPDATE_CONTOSO_COM_USERNAME` | `CONTOSO\svc_gitlab_wu` | Variable | Masked and hidden | Yes | Off | `windows-update/*` |
| `WINDOWS_UPDATE_CONTOSO_COM_PASSWORD` | CONTOSO service account password | Variable | Masked and hidden | Yes | Off | `windows-update/*` |
| `WINDOWS_UPDATE_FABRIKAM_COM_USERNAME` | `FABRIKAM\svc_gitlab_wu` | Variable | Masked and hidden | Yes | Off | `windows-update/*` |
| `WINDOWS_UPDATE_FABRIKAM_COM_PASSWORD` | FABRIKAM service account password | Variable | Masked and hidden | Yes | Off | `windows-update/*` |
| `WSUS_SERVER` | WSUS FQDN used by all selected targets | Variable | Visible | Yes | Off | `windows-update/*` |

Variable names are derived deterministically from the CSV domain: uppercase the DNS name and replace every non-alphanumeric character with an underscore. For example, `contoso.com` becomes `CONTOSO_COM`, producing `WINDOWS_UPDATE_CONTOSO_COM_USERNAME` and `WINDOWS_UPDATE_CONTOSO_COM_PASSWORD`. The inventory validator rejects two different domains that normalize to the same suffix.

The hidden setting can only be selected while creating a variable, not added later. If an existing credential variable is only masked, delete it and recreate it as **Masked and hidden**. Hidden values must also meet GitLab's masking requirements: a single line with no spaces, at least eight characters, and not equal to another variable name. Keep variable expansion off so characters such as `$` in a password remain literal.

Use two variables per domain, rather than one JSON credential variable. GitLab can then mask the password value itself; if a JSON object were stored as one masked value, an accidentally printed extracted password would not necessarily match the masked JSON string. Because one job can process several domains, every domain variable in the matching `windows-update/*` scope is available to that protected job. Use separate per-domain jobs or runners if the domains are separate security boundaries.

The pipeline defines these non-secret defaults in `.gitlab-ci.yml`:

- `WSUS_PORT=8530`
- `WSUS_USE_SSL=false`
- `TARGET_CSV=config/targets/servers.csv`

Change the port to `8531` and SSL to `true` if the WSUS deployment uses TLS. Do not enable `CI_DEBUG_TRACE` in this project because verbose environment logging can expose sensitive data.

Longer term, an external secret manager or a managed service identity is preferable to a static password. The hidden-variable design here meets the requested GitLab implementation and should include password rotation and a narrowly scoped account.

## 5. Protect deployments

1. Run a `validate` pipeline once so GitLab creates no deployment but verifies the inventory.
2. Run a `scan` pipeline once so the relevant environment, such as `windows-update/Production`, exists.
3. On GitLab Premium or Ultimate, go to **Settings > CI/CD > Protected environments** and protect `windows-update/Production` and any other update environments.
4. Add only the operations/change-control group to **Allowed to deploy**.
5. If domains require different operator groups, use separate per-domain jobs/environments rather than the combined-domain mode.
6. In **Settings > CI/CD > Variables**, confirm all credential variables are Protected and environment-scoped.
7. In **Settings > CI/CD > Runners**, confirm the runner is Protected, project-scoped, tagged, and does not accept untagged jobs.
8. In **Settings > CI/CD > General pipelines**, disable pipeline variables after adopting the included pipeline inputs if other project workflows do not require them.
9. Enable **Prevent outdated deployment jobs** and disable retries for rollback deployments in sensitive environments if those settings are available on the GitLab tier.
10. Configure deployment freeze windows for organizational blackout periods.

The deployment job is manual, asks for a second confirmation, is non-interruptible, and uses a per-environment resource group. There is intentionally no automatic retry for an update installation.

## 6. Maintain the target CSV

Edit `config/targets/servers.csv` through a merge request. Required columns are:

| Column | Meaning |
|---|---|
| `ComputerName` | Unique target DNS or NetBIOS name; FQDN is preferred. |
| `Domain` | AD DNS domain expected from `Win32_ComputerSystem.Domain`; it also determines the credential variable names. |
| `Environment` | Selection group, currently `Production` or `NonProduction`. |
| `Wave` | Deployment ring, currently `Wave1` or `Wave2`. |
| `Enabled` | Must be exactly `true` or `false`. Disabled rows can never be selected. |
| `Description` | Optional operator-friendly description. |

Example:

```csv
ComputerName,Domain,Environment,Wave,Enabled,Description
app01.contoso.com,contoso.com,Production,Wave1,true,Production canary
app02.contoso.com,contoso.com,Production,Wave2,true,Production second wave
test01.fabrikam.com,fabrikam.com,NonProduction,Wave1,true,Pre-production validation
```

The committed template ships with every server disabled to prevent an accidental first deployment. The adapter rejects missing columns, invalid booleans, duplicate server names, credential-suffix collisions, invalid hostnames/domains, empty selections, missing credentials, and invalid WSUS ports before installation begins.

Credential selection is intentionally not discovered by trying accounts. For each selected CSV row, the adapter derives the variable names from `Domain`, loads that domain's credential once into an in-memory cache, and retrieves the authenticated target's `Win32_ComputerSystem.Domain`. A non-domain member, domain mismatch, insufficient administrator rights, or connection failure stops the job before the Windows Update scan or installation. Results are saved in `domain-verification.csv`.

## 7. Run update discovery

1. Go to **Build > Pipelines > New pipeline**.
2. Select the protected `main` branch.
3. Set `operation` to `scan`.
4. Choose `target_environment` and `target_wave`. The resulting selection can span multiple CSV domains.
5. Optionally enter a change ticket, requester, and maintenance window.
6. Run the pipeline.
7. Open the `scan_updates` job and download its artifact. It contains domain verification, normalized inventory, selected targets, per-domain change reports, and `scan-summary.csv`.

For regular discovery, create a schedule under **Build > Pipeline schedules** targeting `main`, and set its pipeline inputs to `operation=scan` plus the desired environment and wave. Keep deployments out of schedules.

## 8. Deploy updates

1. Obtain the required change approval and review the latest discovery report.
2. Go to **Build > Pipelines > New pipeline** and select `main`.
3. Set `operation` to `deploy`.
4. Select the approved environment and wave. The selection can include servers from multiple domains.
5. Enter a non-empty `change_ticket`, `requested_by`, and `maintenance_window`.
6. Set `skip_reboot` only when the change plan explicitly requires reboots to remain pending.
7. Create the pipeline. Inventory validation and authenticated domain verification run first.
8. An authorized operator selects the manual `deploy_updates` job and confirms the deployment.
9. Review `domain-verification.csv`, `execution-summary.csv`, and the per-server report folders in the job artifact.

The adapter loads one credential per distinct selected domain and processes selected servers one at a time. The reusable `WindowsUpdate.GitLab` module owns inventory validation, target filtering, domain-derived variable names, credential creation, domain verification, and execution-summary writing. A domain-verification failure prevents all installations in that job. After verification succeeds, an installation failure on one server is recorded and does not prevent the remaining selected servers from being attempted; any server failure makes the job fail after processing the selection.

The standalone entry scripts retain their original single-credential interface for backward compatibility. Do not pass a mixed-domain server list to those scripts with one credential. Use `scripts/Invoke-GitLabWindowsUpdate.ps1` for mixed-domain pipeline runs.

## 9. Module review and recommended evolution

The current module already has several qualities that fit GitLab well:

- Functions are separated into remote, reporting, and orchestration modules.
- WSUS policy and TCP reachability are validated on the target.
- Updates are re-identified by update ID and revision before installation.
- Baseline, change, and post-install status reports are produced.
- Reboots and post-reboot verification are built in.

The included GitLab integration adds or addresses:

- A version-controlled and schema-validated CSV inventory.
- A dedicated `WindowsUpdate.GitLab` module for inventory, credential, selection, verification, and summary logic.
- A `Test-Project.ps1` validation command that checks PowerShell parsing, manifests, sample inventory, filters, and credential-variable naming before every scan or deployment pipeline.
- Environment/wave filtering with an explicit `Enabled` safety control.
- Domain-derived credential selection and authenticated AD-domain verification before scan or installation.
- An in-memory credential cache so each selected domain's hidden variables are read only once.
- Conversion of hidden credential variables into a `PSCredential` without printing them.
- Explicit `-Confirm:$false` only inside a protected manual deployment job.
- Per-server deployment isolation and an aggregate failure summary.
- Unique per-pipeline and per-server output directories.
- A zero-update guard that skips creation of an empty pivot workbook.
- Header-only baseline and status CSVs for successful zero-update runs.
- Artifact retention and concurrency control in GitLab.

Recommended next module changes, after the initial runner proof of concept:

1. Add Pester tests for malformed inventories, duplicate hosts, missing variables, credential-suffix collisions, and mocked domain-verification failures. The included dependency-free validation script covers the main success path and PowerShell parsing.
2. Add a first-class `ContinueOnServerError` option to `Invoke-WindowsUpdateCycle` so the orchestration module, rather than the GitLab adapter, owns aggregate failure behavior.
3. Add a structured result for prerequisite and scan failures to the final status CSV; today, early deployment failures are captured only in the GitLab execution summary.
4. Emit an explicit zero-update row for each scanned server when a multi-server scan finds updates on some targets but not others.
5. Add optional per-row reboot policy and maintenance-window validation if different servers require different reboot behavior.
6. Add configurable category/KB exclusions only if WSUS approvals are not already the authoritative deployment allowlist. By default, keep WSUS approval as the control plane.
7. Add code signing and enforce an AllSigned execution policy when the organization's signing process is ready.
8. Add a transcript with secret-safe logging if GitLab job logs and CSV/XLSX artifacts do not meet audit-retention requirements.
9. If a central runner must reach untrusted domains, add explicit WinRM HTTPS, port, authentication, and certificate-validation parameters throughout `WindowsUpdate.Remote`; otherwise use a dedicated runner inside each isolated domain.

## 10. Is a second GitLab project needed for discovery?

No, not for the normal case. Use one project because scan and deployment use the same code and multi-domain inventory. Separate jobs already provide different execution behavior, scheduling, artifacts, and manual approval.

Create a second deployment project only when there is a real permission boundary, for example:

- A broad audience may view discovery reports, but only a very small group may access deployment pipelines or credentials.
- Different teams own scanning and production deployment.
- Compliance requires deployment code and secrets to have a separate Maintainer population.
- Discovery and deployment require different runners, retention rules, or credentials.

In that model, keep this repository as the discovery/module project and create a tightly controlled deployment project that consumes a tagged module release or triggers a pinned downstream pipeline. Do not copy credentials or mutable branch content between the projects. GitLab specifically recommends a separate deployment project when production secret access must be isolated from Maintainers of the development project.

## GitLab references

- [Install GitLab Runner on Windows](https://docs.gitlab.com/runner/install/windows/)
- [Register runners](https://docs.gitlab.com/runner/register/)
- [Configure runners and protected runners](https://docs.gitlab.com/ci/runners/configure_runners/)
- [Shell executor security](https://docs.gitlab.com/runner/executors/shell/)
- [CI/CD variables: mask, hide, and protect](https://docs.gitlab.com/ci/variables/)
- [Environment-scoped CI/CD variables](https://docs.gitlab.com/ci/environments/#limit-the-environment-scope-of-a-cicd-variable)
- [CI/CD inputs](https://docs.gitlab.com/ci/inputs/)
- [Protected branches](https://docs.gitlab.com/user/project/repository/branches/protected/)
- [Manual and protected jobs](https://docs.gitlab.com/ci/jobs/job_control/)
- [Deployment safety and resource groups](https://docs.gitlab.com/ci/environments/deployment_safety/)
- [Job artifacts](https://docs.gitlab.com/ci/jobs/job_artifacts/)
- [Scheduled pipelines](https://docs.gitlab.com/ci/pipelines/schedules/)
- [PowerShell remoting security considerations](https://learn.microsoft.com/en-us/powershell/scripting/security/remoting/winrm-security)
- [PowerShell remoting and TrustedHosts troubleshooting](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_remote_troubleshooting)
