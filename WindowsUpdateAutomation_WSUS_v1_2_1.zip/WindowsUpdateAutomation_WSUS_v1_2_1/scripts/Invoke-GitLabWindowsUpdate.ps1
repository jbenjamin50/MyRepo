#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet('Validate','Scan','Deploy')]
    [string]$Mode,

    [string]$TargetFile = $(if ($env:TARGET_CSV) {
        $env:TARGET_CSV
    } else {
        Join-Path $PSScriptRoot '..\config\targets\servers.csv'
    }),

    [string]$OutputDirectory = $(if ($env:REPORT_DIR) {
        $env:REPORT_DIR
    } else {
        Join-Path $PSScriptRoot '..\reports'
    }),

    [string]$TargetEnvironment = $(if ($env:TARGET_ENVIRONMENT) {
        $env:TARGET_ENVIRONMENT
    } else {
        'Production'
    }),

    [string]$TargetWave = $(if ($env:TARGET_WAVE) {
        $env:TARGET_WAVE
    } else {
        'Wave1'
    }),

    [string]$WsusServer = $env:WSUS_SERVER,
    [string]$WsusPort = $(if ($env:WSUS_PORT) { $env:WSUS_PORT } else { '8530' }),
    [string]$UseSsl = $(if ($env:WSUS_USE_SSL) { $env:WSUS_USE_SSL } else { 'false' }),
    [string]$SkipReboot = $(if ($env:SKIP_REBOOT) { $env:SKIP_REBOOT } else { 'false' }),
    [string]$ChangeTicket = $env:CHANGE_TICKET,
    [string]$RequestedBy = $env:REQUESTED_BY,
    [string]$MaintenanceWindow = $env:MAINTENANCE_WINDOW,
    [int]$RebootTimeoutSec = 1800
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$moduleRoot = Join-Path $PSScriptRoot '..\Modules'
Import-Module (Join-Path $moduleRoot 'WindowsUpdate.GitLab\WindowsUpdate.GitLab.psd1') -Force

$targetPath = if ([IO.Path]::IsPathRooted($TargetFile)) {
    $TargetFile
} else {
    Join-Path (Get-Location) $TargetFile
}
$reportPath = if ([IO.Path]::IsPathRooted($OutputDirectory)) {
    $OutputDirectory
} else {
    Join-Path (Get-Location) $OutputDirectory
}

New-Item -Path $reportPath -ItemType Directory -Force | Out-Null
$inventory = @(Import-WindowsUpdateTargetInventory -Path $targetPath)
$inventory | Export-Csv `
    -LiteralPath (Join-Path $reportPath 'target-inventory-normalized.csv') `
    -NoTypeInformation `
    -Encoding UTF8

if ($Mode -eq 'Validate') {
    [pscustomobject]@{
        InventoryPath = $targetPath
        TotalServers  = $inventory.Count
        Enabled       = @($inventory | Where-Object Enabled).Count
        Disabled      = @($inventory | Where-Object { -not $_.Enabled }).Count
        Status        = 'Valid'
    }
    return
}

$selectedTargets = @(Select-WindowsUpdateTarget `
    -Inventory $inventory `
    -TargetEnvironment $TargetEnvironment `
    -TargetWave $TargetWave)

if ($selectedTargets.Count -eq 0) {
    throw "No enabled targets matched Environment='$TargetEnvironment' and Wave='$TargetWave'."
}

$selectedTargets | Export-Csv `
    -LiteralPath (Join-Path $reportPath 'selected-targets.csv') `
    -NoTypeInformation `
    -Encoding UTF8

if ([string]::IsNullOrWhiteSpace($WsusServer)) {
    throw 'WSUS_SERVER must be configured as a project CI/CD variable.'
}

$wsusPortNumber = 0
if (-not [int]::TryParse($WsusPort, [ref]$wsusPortNumber) -or
    $wsusPortNumber -lt 1 -or
    $wsusPortNumber -gt 65535) {
    throw "WSUS_PORT must be an integer from 1 through 65535. Received '$WsusPort'."
}

$useSslValue = ConvertTo-WindowsUpdateBoolean -Value $UseSsl -Name 'WSUS_USE_SSL'
$skipRebootValue = ConvertTo-WindowsUpdateBoolean -Value $SkipReboot -Name 'SKIP_REBOOT'
$credentialsByDomain = @{}
foreach ($domain in @($selectedTargets.Domain | Sort-Object -Unique)) {
    $credentialsByDomain[$domain] = New-WindowsUpdateCredential -Domain $domain
}

if ([string]::IsNullOrWhiteSpace($RequestedBy)) {
    $RequestedBy = if ($env:GITLAB_USER_NAME) { $env:GITLAB_USER_NAME } else { 'GitLab CI' }
}

Import-Module (Join-Path $moduleRoot 'WindowsUpdate.Remote\WindowsUpdate.Remote.psd1') -Force
Import-Module (Join-Path $moduleRoot 'WindowsUpdate.Reporting\WindowsUpdate.Reporting.psd1') -Force
Import-Module (Join-Path $moduleRoot 'WindowsUpdate.Orchestrator\WindowsUpdate.Orchestrator.psd1') -Force

$domainVerification = @(Test-WindowsUpdateTargetDomain `
    -Targets $selectedTargets `
    -CredentialsByDomain $credentialsByDomain `
    -Directory $reportPath)
$domainVerification | Format-Table -AutoSize

if ($Mode -eq 'Scan') {
    $scanSummary = [System.Collections.Generic.List[object]]::new()

    foreach ($domainGroup in @($selectedTargets | Group-Object Domain)) {
        $domain = [string]$domainGroup.Name
        $domainOutput = Join-Path $reportPath ("scan-" + (ConvertTo-DomainVariableSuffix -Domain $domain))
        $scanResult = Get-WindowsUpdateChangeReport `
            -ComputerName @($domainGroup.Group.ComputerName) `
            -OutputDirectory $domainOutput `
            -WsusServer $WsusServer `
            -WsusPort $wsusPortNumber `
            -UseSsl:$useSslValue `
            -ChangeTicket $ChangeTicket `
            -RequestedBy $RequestedBy `
            -MaintenanceWindow $MaintenanceWindow `
            -Credential $credentialsByDomain[$domain] `
            -Verbose

        $scanSummary.Add([pscustomobject]@{
            Domain           = $domain
            TargetCount      = @($domainGroup.Group).Count
            UpdateCount      = $scanResult.UpdateCount
            FailedScanCount  = $scanResult.FailedScanCount
            ChangeReportCsv  = $scanResult.ChangeReportCsv
            ChangeReportXlsx = $scanResult.ChangeReportXlsx
        })
    }

    $scanSummary | Export-Csv `
        -LiteralPath (Join-Path $reportPath 'scan-summary.csv') `
        -NoTypeInformation `
        -Encoding UTF8
    $scanSummary

    $failedScanCount = @($scanSummary | Measure-Object FailedScanCount -Sum).Sum
    if ($failedScanCount -gt 0) {
        throw "$failedScanCount target scan(s) failed. Review scan-summary.csv and the domain change reports."
    }

    return
}

if ([string]::IsNullOrWhiteSpace($ChangeTicket)) {
    throw 'A change ticket is required for deployment pipelines.'
}

if (-not (Get-Module -ListAvailable -Name ImportExcel)) {
    throw 'ImportExcel must be installed on the runner before deployment so final XLSX reports can be generated.'
}

$summary = [System.Collections.Generic.List[object]]::new()

foreach ($target in $selectedTargets) {
    $started = Get-Date
    $serverOutput = Join-Path $reportPath ($target.ComputerName -replace '[^A-Za-z0-9._-]', '_')
    $credential = $credentialsByDomain[$target.Domain]

    try {
        $result = Invoke-WindowsUpdateCycle `
            -ComputerName $target.ComputerName `
            -OutputDirectory $serverOutput `
            -WsusServer $WsusServer `
            -WsusPort $wsusPortNumber `
            -UseSsl:$useSslValue `
            -SkipReboot:$skipRebootValue `
            -GenerateChangeReport `
            -ChangeTicket $ChangeTicket `
            -RequestedBy $RequestedBy `
            -MaintenanceWindow $MaintenanceWindow `
            -RebootTimeoutSec $RebootTimeoutSec `
            -Credential $credential `
            -Confirm:$false `
            -Verbose

        $summary.Add([pscustomobject]@{
            ComputerName             = $target.ComputerName
            Domain                   = $target.Domain
            CredentialVariableSuffix = $target.CredentialVariableSuffix
            Environment              = $target.Environment
            Wave                     = $target.Wave
            Result                   = 'Succeeded'
            StartedAt                = $started
            CompletedAt              = Get-Date
            StatusRows               = $result.StatusRows
            StatusCsv                = $result.StatusCsv
            PivotReport              = $result.PivotReport
            Error                    = $null
        })
    }
    catch {
        Write-Error -Message "Deployment failed for $($target.ComputerName): $($_.Exception.Message)" -ErrorAction Continue
        $summary.Add([pscustomobject]@{
            ComputerName             = $target.ComputerName
            Domain                   = $target.Domain
            CredentialVariableSuffix = $target.CredentialVariableSuffix
            Environment              = $target.Environment
            Wave                     = $target.Wave
            Result                   = 'Failed'
            StartedAt                = $started
            CompletedAt              = Get-Date
            StatusRows               = $null
            StatusCsv                = $null
            PivotReport              = $null
            Error                    = $_.Exception.Message
        })
    }
}

Write-WindowsUpdateExecutionSummary -Summary @($summary) -Directory $reportPath
$summary

$failedServers = @($summary | Where-Object Result -eq 'Failed')
if ($failedServers.Count -gt 0) {
    throw "$($failedServers.Count) server deployment(s) failed. Review execution-summary.csv."
}
