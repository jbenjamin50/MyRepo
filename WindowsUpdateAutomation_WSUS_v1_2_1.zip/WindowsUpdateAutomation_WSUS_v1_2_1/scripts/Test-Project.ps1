#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Assert-ProjectCondition {
    param(
        [Parameter(Mandatory)][bool]$Condition,
        [Parameter(Mandatory)][string]$Message
    )

    if (-not $Condition) {
        throw $Message
    }
}

$projectRoot = Split-Path -Parent $PSScriptRoot
$parseErrors = [System.Collections.Generic.List[string]]::new()
$sourceFiles = @(
    Get-ChildItem -LiteralPath $projectRoot -Recurse -File |
        Where-Object Extension -in @('.ps1','.psm1','.psd1')
)

foreach ($sourceFile in $sourceFiles) {
    $tokens = $null
    $errors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        $sourceFile.FullName,
        [ref]$tokens,
        [ref]$errors
    )

    foreach ($parseError in @($errors)) {
        $parseErrors.Add("$($sourceFile.FullName):$($parseError.Extent.StartLineNumber): $($parseError.Message)")
    }
}

if ($parseErrors.Count -gt 0) {
    throw "PowerShell parse validation failed:`n$($parseErrors -join "`n")"
}

$moduleManifests = @(Get-ChildItem -LiteralPath (Join-Path $projectRoot 'Modules') -Recurse -Filter '*.psd1')
foreach ($manifest in $moduleManifests) {
    Test-ModuleManifest -Path $manifest.FullName -ErrorAction Stop | Out-Null
}

$gitLabManifest = Join-Path $projectRoot 'Modules\WindowsUpdate.GitLab\WindowsUpdate.GitLab.psd1'
Import-Module $gitLabManifest -Force -ErrorAction Stop

$credentialNames = Get-WindowsUpdateCredentialVariableName -Domain 'contoso.com'
Assert-ProjectCondition `
    -Condition ($credentialNames.UsernameVariable -eq 'WINDOWS_UPDATE_CONTOSO_COM_USERNAME') `
    -Message 'Domain-to-username-variable mapping is incorrect.'
Assert-ProjectCondition `
    -Condition ($credentialNames.PasswordVariable -eq 'WINDOWS_UPDATE_CONTOSO_COM_PASSWORD') `
    -Message 'Domain-to-password-variable mapping is incorrect.'

$inventoryPath = Join-Path $projectRoot 'config\targets\servers.csv'
$inventory = @(Import-WindowsUpdateTargetInventory -Path $inventoryPath)
Assert-ProjectCondition -Condition ($inventory.Count -gt 0) -Message 'The sample target inventory has no rows.'
Assert-ProjectCondition `
    -Condition (@($inventory | Where-Object { [string]::IsNullOrWhiteSpace($_.Domain) }).Count -eq 0) `
    -Message 'At least one target inventory row has no domain.'

$enabledSampleTargets = @(
    [pscustomobject]@{ Enabled = $true; Environment = 'Production'; Wave = 'Wave1' },
    [pscustomobject]@{ Enabled = $false; Environment = 'Production'; Wave = 'Wave1' },
    [pscustomobject]@{ Enabled = $true; Environment = 'NonProduction'; Wave = 'Wave1' }
)
$selected = @(Select-WindowsUpdateTarget `
    -Inventory $enabledSampleTargets `
    -TargetEnvironment 'Production' `
    -TargetWave 'Wave1')
Assert-ProjectCondition -Condition ($selected.Count -eq 1) -Message 'Target filtering did not enforce Enabled, Environment, and Wave.'

$collisionInventoryPath = Join-Path ([IO.Path]::GetTempPath()) ("windows-update-domain-collision-{0}.csv" -f [guid]::NewGuid())
$collisionDetected = $false
try {
    @(
        'ComputerName,Domain,Environment,Wave,Enabled',
        'server01.a-b.com,a-b.com,Production,Wave1,false',
        'server02.a.b-com,a.b-com,Production,Wave1,false'
    ) | Set-Content -LiteralPath $collisionInventoryPath -Encoding UTF8

    try {
        Import-WindowsUpdateTargetInventory -Path $collisionInventoryPath | Out-Null
    }
    catch {
        $collisionDetected = $_.Exception.Message -like '*same credential-variable suffix*'
    }
}
finally {
    Remove-Item -LiteralPath $collisionInventoryPath -Force -ErrorAction SilentlyContinue
}
Assert-ProjectCondition -Condition $collisionDetected -Message 'Credential-variable suffix collisions are not being rejected.'

$missingVariableNames = Get-WindowsUpdateCredentialVariableName -Domain 'missing.invalid'
[Environment]::SetEnvironmentVariable($missingVariableNames.UsernameVariable, $null, 'Process')
[Environment]::SetEnvironmentVariable($missingVariableNames.PasswordVariable, $null, 'Process')
$missingCredentialRejected = $false
try {
    New-WindowsUpdateCredential -Domain 'missing.invalid' | Out-Null
}
catch {
    $missingCredentialRejected = $_.Exception.Message -like "*$($missingVariableNames.UsernameVariable)*"
}
Assert-ProjectCondition -Condition $missingCredentialRejected -Message 'A missing domain credential variable was not rejected with the expected variable name.'

[pscustomobject]@{
    PowerShellFiles = $sourceFiles.Count
    ModuleManifests = $moduleManifests.Count
    InventoryRows   = $inventory.Count
    Status          = 'Valid'
}
